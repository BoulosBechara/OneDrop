package com.example.dell.onedrop;

import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Signup extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        Button btn=(Button) findViewById(R.id.Submit);
        final EditText mail=(EditText) findViewById(R.id.EMail);
        final EditText fname=(EditText) findViewById(R.id.FirstName);
        final EditText lname=(EditText) findViewById(R.id.LastName);
        final EditText id=(EditText) findViewById(R.id.ID);
        final EditText pass=(EditText) findViewById(R.id.Pass);
        final EditText repass=(EditText) findViewById(R.id.RePass);

        btn.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()){
                    case MotionEvent.ACTION_DOWN:
                        return true;
                    case MotionEvent.ACTION_UP:

                        if(!isEmailValid(mail.getText())) {
                            Toast.makeText(getApplicationContext(), "InValid Email Try Again", Toast.LENGTH_SHORT).show();
                            mail.getBackground().setColorFilter(Color.parseColor("#ff0000"), PorterDuff.Mode.DARKEN);
                        }
                        else
                        {
                            Toast.makeText(getApplicationContext(), "Valid Email", Toast.LENGTH_SHORT).show();
                            mail.getBackground().setColorFilter(Color.parseColor("#0000ff00"), PorterDuff.Mode.DARKEN);
                        }

                        if(!isFname(fname.getText()))
                        {
                            Toast.makeText(getApplicationContext(), "InValid First Name Try Again", Toast.LENGTH_SHORT).show();
                            fname.getBackground().setColorFilter(Color.parseColor("#ff0000"), PorterDuff.Mode.DARKEN);
                        }
                        else
                        {
                            Toast.makeText(getApplicationContext(), "Valid First Name", Toast.LENGTH_SHORT).show();
                            fname.getBackground().setColorFilter(Color.parseColor("#0000ff00"), PorterDuff.Mode.DARKEN);
                        }

                        if(!isFname(lname.getText()))
                        {
                            Toast.makeText(getApplicationContext(), "InValid Last Name Try Again", Toast.LENGTH_SHORT).show();
                            lname.getBackground().setColorFilter(Color.parseColor("#ff0000"), PorterDuff.Mode.DARKEN);
                        }
                        else
                        {
                            Toast.makeText(getApplicationContext(), "Valid Last Name", Toast.LENGTH_SHORT).show();
                            lname.getBackground().setColorFilter(Color.parseColor("#0000ff00"), PorterDuff.Mode.DARKEN);
                        }

                        if(!isIDValid(id.getText()))
                        {
                            Toast.makeText(getApplicationContext(), "InValid id Try Again", Toast.LENGTH_SHORT).show();
                            id.getBackground().setColorFilter(Color.parseColor("#ff0000"), PorterDuff.Mode.DARKEN);
                        }
                        else
                        {
                            Toast.makeText(getApplicationContext(), "Valid id", Toast.LENGTH_SHORT).show();
                            id.getBackground().setColorFilter(Color.parseColor("#0000ff00"), PorterDuff.Mode.DARKEN);
                        }

                        if(!isPassValid(pass.getText()))
                        {
                            Toast.makeText(getApplicationContext(), "InValid password Try Again", Toast.LENGTH_SHORT).show();
                            pass.getBackground().setColorFilter(Color.parseColor("#ff0000"), PorterDuff.Mode.DARKEN);
                        }
                        else
                        {
                            Toast.makeText(getApplicationContext(), "Valid password", Toast.LENGTH_SHORT).show();
                            pass.getBackground().setColorFilter(Color.parseColor("#0000ff00"), PorterDuff.Mode.DARKEN);
                        }

                        if(!isrePassValid(repass.getText(),pass.getText()))
                        {
                            Toast.makeText(getApplicationContext(), "InValid repassword Try Again", Toast.LENGTH_SHORT).show();
                            repass.getBackground().setColorFilter(Color.parseColor("#ff0000"), PorterDuff.Mode.DARKEN);
                        }
                        else
                        {
                            Toast.makeText(getApplicationContext(), "Valid repassword", Toast.LENGTH_SHORT).show();
                            repass.getBackground().setColorFilter(Color.parseColor("#0000ff00"), PorterDuff.Mode.DARKEN);
                        }


                        return true;
                }

                return false;
            }
        });
    }
    public static boolean isFname(Editable fname)
    {
        boolean isValid=false;

        String expression="^[\\w\\.-]+[A-Z]$";
        CharSequence inputStr=fname;

        Pattern pattern= Pattern.compile(expression,Pattern.CASE_INSENSITIVE);
        Matcher matcher=pattern.matcher(inputStr);
        if(matcher.matches()){
            isValid=true;
        }
        return isValid;
    }

    public static boolean isEmailValid(Editable email)
    {
        boolean isValid=false;

        String expression="^[\\w\\.-]+@([\\w\\-]+\\.)+[A-Z]{2,4}$";
        CharSequence inputStr=email;

        Pattern pattern= Pattern.compile(expression,Pattern.CASE_INSENSITIVE);
        Matcher matcher=pattern.matcher(inputStr);
        if(matcher.matches()){
            isValid=true;
        }
        return isValid;
    }

    public static boolean isIDValid(Editable id)
    {
        if(id.length()!=9)
            return false;
        return true;
    }

    public static boolean isPassValid(Editable pass)
    {
        if(pass.length()<8)
            return false;
        return true;
    }

    public static boolean isrePassValid(Editable repass,Editable pass)
    {
        if(pass.toString().compareTo(repass.toString())!=0 || repass.length()<8)
            return false;
        return true;
    }
}
